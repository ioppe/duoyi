# whitelist-v5-events-only 诊断 APK 构建报告（非最终验证）

- workdir: /Users/sky/Documents/.pi-desktop/data/scratch/0ce5368b-4129-4faf-bd6d-154cba571b08/android-candidate-whitelist-v5-events-only
- source head (manifest): cdee4e44e932e8c85a8fb153d2fb405db41c90c1
- 退出码: pub get 0（第一次两次失败已纠正，见下）；build 0

## 命令 / 环境
flutter: /Users/sky/Library/Developer/duoyi/flutter-3.44.1/bin/flutter (3.44.1 / Dart 3.12.1)
JAVA_HOME jdk-17, ANDROID_HOME/SDK_ROOT /Users/sky/Library/Android/sdk, GRADLE_USER_HOME duoyi/gradle, FLUTTER_STORAGE_BASE_URL=https://storage.flutter-io.cn, TZ=UTC
1) flutter pub get --enforce-lockfile → 0（11s）
2) python3 scripts/flutter_with_config.py build apk --profile --no-pub --target-platform android-arm64 --dart-define=DUOYI_SERVER_URL=http://127.0.0.1:18763 → 0（49s）

## 环境偏差（必须记录）
- 第一次 pub get 失败 exit 69：PUB_HOSTED_URL 被设成 storage 域名 → 找不到包。
- 第二次 exit 65：PUB_HOSTED_URL=https://pub.flutter-io.cn → 镜像重解析，--enforce-lockfile 拒绝（lockfile 固定 url https://pub.dev）。
- 结论：本仓库 lockfile 固定 pub.dev，构建时不得设 PUB_HOSTED_URL（与 v4 相同做法）；仅设 FLUTTER_STORAGE_BASE_URL。

## 产物
path: .../android-candidate-whitelist-v5-events-only/build/app/outputs/flutter-apk/app-profile.apk
sha256 51b8c6209a213d8ea2113af82990c97fbed2c8e6f0ff726b5e7a4d503ebb4620
size 105691917 bytes
package com.duoyi.duoyi.focuscheck / versionName 2.0.0 / versionCode 140023 / label 多仪·专注验证 / MainActivity com.duoyi.duoyi.MainActivity
minSdk 24, targetSdk 36, native-code arm64-v8a, armeabi-v7a, x86_64（与 v3/v4 相同）
签名：apksigner(jar 36.0.0, JDK17) exit 0 → Verifies, v2 true, 1 signer, CN=Android Debug, cert sha256 b4ea31fb7e30de9c25dea0f0ddc4252b357f0cb9e3a7a1e353250c4188c2b1d3

## Accessibility XML（APK 实际值, aapt xmltree）
accessibilityEventTypes=0x400828 = typeViewFocused(0x8)|typeWindowStateChanged(0x20)|typeWindowContentChanged(0x800)|typeWindowsChanged(0x400000)
canRetrieveWindowContent=0x0 (false), flags=0x10, timeout=0x64(100ms)
实际多出的 2 个类型正是 typeViewFocused / typeWindowContentChanged；service meta-data android:resource=@0x7f11000e

## Manifest metadata（APK 实际值）
flutter_deeplinking_enabled = (type 0x12) 0x0 = false

## 源漂移 / lock / identity
manifest 1270 文件；构建前 missing 0, extra 0, mismatch 3 = 声明的 3 个 identity 文件
构建后 missing 0, mismatch 4：新增 lib/l10n/generated/app_localizations_en.dart（构建期 gen_l10n 重生成；唯一差异是同一句话里 " 被写成 \"，语义不变）
pubspec.lock sha256 f8d521ef9f8b6a0673d1e8ec51064f71b1a71dcfa8253fe4cee25df6c409db7b 前后一致
identity 差异仅：applicationId → com.duoyi.duoyi.focuscheck；app_name → 多仪·专注验证；deep-link scheme → duoyi-focus-check
copy 缺 gradlew/gradlew.bat/gradle-wrapper.jar（git ignored）：从 live repo android/ 复制，逐字节相同（hash 见 wrapper-copy.shasum.txt）；local.properties 由构建生成 buildMode=profile
live repo 未改动（identity 文件 mtime 仍为 11-04）

## 无 AppTask 实验（源 + 产物证据）
service sha256 ba7f8483... 与 v3-diagnostic 完全一致；lib/ + android/app/src 中 ActivityManager|AppTask|moveToFront 命中 0
dex 对照：v3(无实验) moveToFront=1/getAppTasks=0/marker=0；v4(有实验) 2/1/1；v5 1/0/0
→ v5 与 v3 基线一致；单个 moveToFront 出现在 desugar 库 classes19.dex，无 ActivityManager/TaskInfo 引用

## 未跑
flutter analyze、完整 flutter test、native gradle 单测、设备安装/ADB、fixture 后端、release 签名
